import 'package:flutter/material.dart';

class AppTheme {
  static const Color primaryNavy = Color(0xFF0F1923);
  static const Color secondaryColor = Color(0xFF3B82F6);

  static const Color safeColor = Color(0xFF22C55E);
  static const Color warningColor = Color(0xFFF59E0B);
  static const Color emergencyRed = Color(0xFFEF4444);
  static const Color criticalColor = emergencyRed;
  static const Color offlineColor = Color(0xFF94A3B8);

  static ThemeData get light {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryNavy,
      primary: primaryNavy,
      secondary: secondaryColor,
      brightness: Brightness.light,
      surface: const Color(0xFFF8FAFC),
    );
    return _buildTheme(colorScheme);
  }

  static ThemeData get dark {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: primaryNavy,
      primary: const Color(0xFF1E293B),
      secondary: secondaryColor,
      brightness: Brightness.dark,
      surface: const Color(0xFF0F172A),
    );
    return _buildTheme(colorScheme);
  }

  static ThemeData _buildTheme(ColorScheme cs) {
    return ThemeData(
      useMaterial3: true,
      colorScheme: cs,
      scaffoldBackgroundColor: cs.surface,
      cardTheme: CardThemeData(
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(color: cs.outlineVariant.withValues(alpha: 0.3)),
        ),
        color: cs.surface,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: cs.surface,
        foregroundColor: cs.onSurface,
        elevation: 0,
        centerTitle: false,
        scrolledUnderElevation: 1,
      ),
      navigationBarTheme: NavigationBarThemeData(
        elevation: 0,
        backgroundColor: cs.surface,
        indicatorColor: cs.secondaryContainer,
        height: 64,
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: cs.surface,
        indicatorColor: cs.secondaryContainer,
      ),
      dividerTheme: DividerThemeData(
        color: cs.outlineVariant.withValues(alpha: 0.3),
        thickness: 1,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
      textTheme: TextTheme(
        displayLarge: TextStyle(fontSize: 34, fontWeight: FontWeight.w800, color: cs.onSurface),
        displayMedium: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: cs.onSurface),
        displaySmall: TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: cs.onSurface),
        headlineLarge: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, color: cs.onSurface),
        headlineMedium: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, color: cs.onSurface),
        headlineSmall: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: cs.onSurface),
        titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: cs.onSurface),
        titleMedium: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: cs.onSurface),
        titleSmall: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: cs.onSurface),
        bodyLarge: TextStyle(fontSize: 17, fontWeight: FontWeight.w400, color: cs.onSurface),
        bodyMedium: TextStyle(fontSize: 15, fontWeight: FontWeight.w400, color: cs.onSurface),
        bodySmall: TextStyle(fontSize: 13, fontWeight: FontWeight.w400, color: cs.onSurfaceVariant),
        labelLarge: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: cs.onSurface),
        labelMedium: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: cs.onSurface),
        labelSmall: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: cs.onSurfaceVariant),
      ),
      fontFamily: 'Roboto',
    );
  }

  const AppTheme._();
}
